package com.sathya.Sathyatelcalldetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SathyatelCalldetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SathyatelCalldetailsApplication.class, args);
	}

}

