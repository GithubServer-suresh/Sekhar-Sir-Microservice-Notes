package com.sathya.sathyatelcloudconfigserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SathyatelCloudConfigServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SathyatelCloudConfigServerApplication.class, args);
	}

}

