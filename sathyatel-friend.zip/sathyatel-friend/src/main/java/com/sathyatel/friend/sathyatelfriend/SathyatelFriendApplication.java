package com.sathyatel.friend.sathyatelfriend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SathyatelFriendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SathyatelFriendApplication.class, args);
	}

}

